const socket = io('http://localhost:4557');
socket.on('connect', () => {
	//Do you work in here
	//Methods to look at 
	// socket.emit(eventName,data);
	// socket.on(eventName, callbackFunction)

});